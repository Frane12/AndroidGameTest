import hr.frane.zvjezdana.GameRules;
public class RulesTest {
    static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    static float simulate(int fps){GameRules.Motion m=new GameRules.Motion();double accumulator=0;for(int i=0;i<fps*2;i++){accumulator+=1.0/fps;while(accumulator+1e-9>=1.0/120){m.step(350,1f/120);accumulator-=1.0/120;}}return m.x;}
    public static void main(String[] args){
        int[] scores={0,149,150,399,400,799,800,1399,1400,999999};
        int[] levels={0,0,1,1,2,2,3,3,4,4};
        for(int i=0;i<scores.length;i++)check(GameRules.levelFor(scores[i])==levels[i],"Level boundary "+scores[i]);
        for(int level=0;level<5;level++)for(int i=0;i<1000;i++){
            int kind=GameRules.chooseKind(level,i/1000f,i);
            check(kind>=0&&kind<=6,"Unknown kind");
            check(kind<=2||kind<=2+level,"Object unlocked too early");
            check(kind==2?GameRules.points(kind)==0:GameRules.points(kind)>0,"Bad scoring");
        }
        GameRules.Motion m=new GameRules.Motion();
        for(int i=0;i<12000;i++){m.step(i%240<120?-100:500,1f/120);check(m.x>=36&&m.x<=364,"Escaped bounds");check(Math.abs(m.v)<=540,"Speed cap");}
        for(int i=0;i<480;i++)m.step(200,1f/120);
        check(Math.abs(m.x-200)<.1&&Math.abs(m.v)<.8,"Does not settle");
        for(int fps:new int[]{30,60,90,120,144})check(Math.abs(simulate(fps)-350)<.1,"Frame rate dependent movement "+fps);
        check(GameRules.MAX_SPARKS>=30&&GameRules.MAX_DROPS>=20,"Invalid visual limits");
        check(GameRules.cameraTarget(200)==0,"Camera centre");
        check(GameRules.cameraTarget(36)<0&&GameRules.cameraTarget(364)>0,"Camera direction");
        for(float x=-1600;x<=1600;x+=7.25f){
            float a=GameRules.wrap(x,-90,580);
            check(a>=-90&&a<580,"Parallax wrap bounds "+x);
            check(Math.abs(a-GameRules.wrap(x+670,-90,580))<.002,"Parallax seam "+x);
        }
        System.out.println("PASS: camera/wrap/scene limits + level boundaries, unlocks, scoring, movement bounds, reversal, settling and 30/60/90/120/144 Hz fixed-step playback");
    }
}
