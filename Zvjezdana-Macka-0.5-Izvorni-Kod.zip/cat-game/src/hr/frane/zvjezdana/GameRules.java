package hr.frane.zvjezdana;

/** Pure game rules, also exercised by the host-side regression check. */
public final class GameRules {
    public static final int MAX_DROPS=48,MAX_SPARKS=110;
    public static float cameraTarget(float catX){return (catX-200)*.3f;}
    public static float wrap(float value,float min,float max){float span=max-min;return min+((value-min)%span+span)%span;}
    public static final int[] THRESHOLDS={0,150,400,800,1400};
    public static int levelFor(int score){int level=0;while(level<4&&score>=THRESHOLDS[level+1])level++;return level;}
    public static int points(int kind){switch(kind){case 0:return 10;case 1:return 25;case 3:return 30;case 4:return 35;case 5:return 45;case 6:return 60;default:return 0;}}
    public static int chooseKind(int level,float roll,int choice){if(roll<.30f)return 2;if(roll<.54f)return 0;if(roll<.72f||level==0)return 1;return 3+(choice & 0x7fffffff)%level;}
    public static final class Motion {
        public float x=200,v=0,phase=0;
        public void reset(){x=200;v=0;phase=0;}
        public void step(float target,float dt){
            target=Math.max(36,Math.min(364,target));
            float a=Math.max(-3200,Math.min(3200,(target-x)*160-v*25));
            v=Math.max(-540,Math.min(540,v+a*dt));
            float old=x;x+=v*dt;
            if(x<36){x=36;v=Math.max(0,v);}if(x>364){x=364;v=Math.min(0,v);}
            if(Math.abs(target-x)<.08f&&Math.abs(v)<.8f){x=target;v=0;}
            phase+=Math.abs(x-old)*.085f;
        }
    }
}
