package hr.frane.zvjezdana;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Vibrator;
import android.os.VibrationEffect;
import android.view.*;
import android.graphics.*;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends Activity {
    Game game;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        game = new Game(); setContentView(game);
    }
    @Override protected void onPause() { super.onPause(); game.saveBest(); game.active=false; if(game.state==1||game.state==4){game.resumeState=game.state;game.state=3;} if(game.vibrator!=null)game.vibrator.cancel(); }
    @Override protected void onResume() { super.onResume(); if(game!=null){game.active=true;game.last=0;game.invalidate();} }
    class Drop { float x,y,speed,age=0,angle=0; int kind; Drop(float x,float speed,int kind){this.x=x;this.y=150;this.speed=speed;this.kind=kind;} }
    class Spark {
        float x,y,vx,vy,life,total; int color;
        Spark(float x,float y,float vx,float vy,float life,int color){this.x=x;this.y=y;this.vx=vx;this.vy=vy;this.life=this.total=life;this.color=color;}
    }
    class Game extends View {
        Paint p=new Paint(3); Random random=new Random(); ArrayList<Drop> drops=new ArrayList<Drop>();
        float w=400,h=780,scale=1,cat=200,target=200,elapsed=0,spawn=0,invincible=0,flash=0;
        ArrayList<Spark> sparks=new ArrayList<Spark>();
        Vibrator vibrator=(Vibrator)getSystemService(VIBRATOR_SERVICE);
        float deathTimer=0; int resumeState=1;
        GameRules.Motion motion=new GameRules.Motion();
        float accumulator=0,clock=0,facing=1,joy=0,levelBanner=0,theme=0, camera=0;
        int level=0;
        final String[] names={"Zvjezdani vrt","Riblja laguna","Slatki oblaci","Kristalna špilja","Svemirska gozba"};
        final String[] top={"#101D36","#103D50","#402A55","#182B4C","#180F39"};
        final String[] bottom={"#264765","#286B72","#815474","#385D83","#54437D"};
        final String[] meteorNames={"Vrtni meteor","Vodeni meteor","Karamelni meteor","Kristalni meteor","Kozmički meteor"};
        long last=0; int state=0,score=0,lives=3,best; boolean active=true;
        Game(){super(MainActivity.this); best=getPreferences(0).getInt("best",0);setLayerType(View.LAYER_TYPE_HARDWARE,null);}
        void saveBest(){getPreferences(0).edit().putInt("best",best).apply();}
        int col(String s){return Color.parseColor(s);}
        void paint(String color){p.setColor(col(color));p.setStyle(Paint.Style.FILL);p.setShader(null);}
        void circle(Canvas c,float x,float y,float r,String color){paint(color);c.drawCircle(x,y,r,p);}
        void box(Canvas c,float x,float y,float width,float height,float radius,String color){paint(color);c.drawRoundRect(x,y,x+width,y+height,radius,radius,p);}
        void label(Canvas c,String text,float x,float y,float size,String color,boolean bold){paint(color);p.setTextSize(size);p.setTypeface(bold?Typeface.create("sans-serif",Typeface.BOLD):Typeface.create("sans-serif",Typeface.NORMAL));p.setTextAlign(Paint.Align.CENTER);c.drawText(text,x,y,p);}
        void star(Canvas c,float x,float y,float r,String color){Path path=new Path();for(int i=0;i<10;i++){double a=-Math.PI/2+i*Math.PI/5;float rr=i%2==0?r:r*.46f;float xx=x+(float)Math.cos(a)*rr,yy=y+(float)Math.sin(a)*rr;if(i==0)path.moveTo(xx,yy);else path.lineTo(xx,yy);}path.close();paint(color);c.drawPath(path,p);}
        @SuppressWarnings("deprecation")
        void buzz(int ms){
            if(vibrator==null||!vibrator.hasVibrator())return;
            if(Build.VERSION.SDK_INT>=26)vibrator.vibrate(VibrationEffect.createOneShot(ms,VibrationEffect.DEFAULT_AMPLITUDE));
            else vibrator.vibrate(ms);
        }
        void donut(Canvas c,float x,float y){
            circle(c,x,y,18,"#ECAE6C");circle(c,x,y-1,15,"#FF8DB5");
            String[] colors={"#FFF0AD","#FFFFFF","#89E1DC"};
            for(int i=0;i<9;i++){double a=i*Math.PI*2/9;float xx=x+(float)Math.cos(a)*11,yy=y+(float)Math.sin(a)*11;box(c,xx-2,yy-1,5,2,1,colors[i%3]);}
            circle(c,x,y,6,"#26415B");
        }
        // Each world has its own animated hazard silhouette and palette.
        void bomb(Canvas c,float x,float y){
            float pulse=(float)Math.sin(clock*8)*2;
            if(level==0){ // red-hot rock, with a burning tail
                paint("#FF8C4E");Path flame=new Path();flame.moveTo(-9,-9);flame.lineTo(-27,-31-pulse);flame.lineTo(-18,-7);flame.lineTo(-34,-13);flame.lineTo(-13,12);flame.close();c.drawPath(flame,p);
                circle(c,x,y,18,"#533C4C");circle(c,x-5,y-5,7,"#A96557");circle(c,x+8,y+7,4,"#FFCB79");
            }else if(level==1){ // spinning sea mine
                for(int i=0;i<8;i++){double a=i*Math.PI/4+clock*.6;float xx=(float)Math.cos(a),yy=(float)Math.sin(a);paint("#5FE2DD");p.setStrokeWidth(5);c.drawLine(xx*14,yy*14,xx*25,yy*25,p);}
                circle(c,x,y,18,"#145A70");circle(c,x-5,y-6,6,"#90FFF0");circle(c,x+6,y+5,4,"#0A3047");
            }else if(level==2){ // candy meteor, dangerous despite the icing
                circle(c,x,y,19,"#AA5B7E");circle(c,x,y-3,16,"#FF91B5");
                for(int i=0;i<7;i++){double a=i*Math.PI*2/7+clock*.3;float xx=(float)Math.cos(a)*11,yy=(float)Math.sin(a)*11;box(c,xx-3,yy-1,6,3,1,i%2==0?"#FFE1A3":"#B6F4FF");}
                circle(c,x,y,6,"#5B345F");
            }else if(level==3){ // sharp rotating crystal
                Path gem=new Path();gem.moveTo(0,-25-pulse);gem.lineTo(17,-8);gem.lineTo(13,16);gem.lineTo(0,25+pulse);gem.lineTo(-17,7);gem.lineTo(-13,-14);gem.close();paint("#63D8FF");c.drawPath(gem,p);
                Path face=new Path();face.moveTo(0,-25-pulse);face.lineTo(0,25+pulse);face.lineTo(13,16);face.lineTo(17,-8);face.close();paint("#2269B1");c.drawPath(face,p);star(c,-5,-7,5,"#E5FFFF");
            }else{ // ringed dark-matter asteroid
                circle(c,x,y,18,"#34235C");circle(c,x-5,y-6,7,"#9E7BE9");
                paint("#FFB4EF");p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);c.drawOval(-29,-9,29,10,p);p.setStyle(Paint.Style.FILL);
                star(c,9,7,5,"#F9D5FF");
            }
            label(c,"!",x+2,y+6,14,"#FFFFFF",true);
        }
        void burst(float x,float y,boolean explosion){
            int count=explosion?30:12;
            // Bound particle storage even if pickups happen faster than particles expire.
            while(sparks.size()+count>GameRules.MAX_SPARKS)sparks.remove(0);
            for(int i=0;i<count;i++){double a=random.nextDouble()*Math.PI*2;float speed=(explosion?65:30)+random.nextFloat()*(explosion?160:65);sparks.add(new Spark(x,y,(float)Math.cos(a)*speed,(float)Math.sin(a)*speed,explosion?.65f:.4f,col(explosion?(i%2==0?"#FFAD55":"#FFE8A3"):"#FFE09A")));}
        }
        void effects(float dt){
            clock+=dt;joy=Math.max(0,joy-dt);levelBanner=Math.max(0,levelBanner-dt);
            theme=Math.min(level,theme+dt*.8f);
            camera+=(GameRules.cameraTarget(cat)-camera)*Math.min(1,dt*2.5f);
            flash=Math.max(0,flash-dt);
            for(int i=sparks.size()-1;i>=0;i--){Spark s=sparks.get(i);s.life-=dt;if(s.life<=0){sparks.remove(i);continue;}s.x+=s.vx*dt;s.y+=s.vy*dt;s.vy+=110*dt;}
            if(state==4){deathTimer-=dt;if(deathTimer<=0)state=2;}
        }
        int mix(int a,int b,float t){return Color.rgb((int)(Color.red(a)+(Color.red(b)-Color.red(a))*t),(int)(Color.green(a)+(Color.green(b)-Color.green(a))*t),(int)(Color.blue(a)+(Color.blue(b)-Color.blue(a))*t));}
        int themeColor(String[] colors){int i=(int)theme;return mix(col(colors[i]),col(colors[Math.min(4,i+1)]),theme-i);}
        // v0.4: a small procedural parallax scene. The same scene coordinates are
        // redrawn at different speeds: far stars, clouds, ridges, and close grass.
        // No bitmaps, network requests or per-frame particle allocations are needed.
        float wave(float t){return (float)Math.sin(t);}
        float depthX(float x,float speed,float drift){
            return GameRules.wrap(x-camera*speed+clock*drift,-90,580);
        }
        void cloud(Canvas c,float x,float y,float size,int color){
            p.setShader(null);p.setStyle(Paint.Style.FILL);p.setColor(color);
            c.drawOval(x-size*1.4f,y-size*.24f,x+size*1.4f,y+size*.35f,p);
            c.drawOval(x-size*.87f,y-size*.64f,x+size*.14f,y+size*.3f,p);
            c.drawOval(x-size*.05f,y-size*.93f,x+size*.85f,y+size*.32f,p);
        }
        void hills(Canvas c,float base,float height,int color,float parallax,float travel){
            // The ridge has an exact 800-unit period, so the wrap is seamless.
            float shift=GameRules.wrap(-camera*parallax+clock*travel,0,800);
            Path path=new Path();path.moveTo(-1400,h);path.lineTo(-1400,base);
            for(int i=-24;i<=24;i++){
                float x=i*50+shift;
                float y=base-height*(.48f+.28f*wave(i*(float)(Math.PI/8)+parallax*4+level*.3f)
                    +.23f*wave(i*(float)(Math.PI/4)+parallax*7));
                path.lineTo(x,y);
            }
            path.lineTo(1600,h);path.close();p.setShader(null);p.setColor(color);
            p.setStyle(Paint.Style.FILL);c.drawPath(path,p);
        }
        void background(Canvas c){
            int sky=themeColor(top), valley=themeColor(bottom);
            p.setShader(new LinearGradient(0,0,0,h,sky,valley,Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p);p.setShader(null);
            final int starColor=mix(sky,col("#F3EBDC"),.65f);
            // Far field moves slowly, twinkles asynchronously and never flickers
            // due to randomness being called in onDraw().
            for(int i=0;i<65;i++){
                float sx=GameRules.wrap((i*137+29)%480-camera*.075f+clock*.35f,-15,430);
                float sy=148+(i*173%390)*Math.min(1,(h-210)/450);
                float blink=.62f+.38f*wave(clock*(.8f+(i%5)*.17f)+i*2.17f);
                p.setColor(starColor);
                p.setAlpha((int)(65+150*blink));
                c.drawCircle(sx,sy, .6f+(i%5==0?1.2f:.35f),p);
            }
            p.setAlpha(255);
            // Shooting star: its color follows the current level palette.
            String[] trails={"#FFE5A0","#79F9E9","#FFD1E8","#9EEAFF","#D9ADFF"};
            // Slow meteor: visible for a little less than a second per cycle.
            float meteor=(clock+2.5f)%12f;
            if(meteor<.9f){
                float x=475-meteor*235,y=186+meteor*115;
                p.setColor(col(trails[level]));p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(2.3f);p.setAlpha((int)(210*(1-meteor/.9f)));
                c.drawLine(x+42,y-21,x,y,p);p.setAlpha(255);
                circle(c,x,y,2.5f,trails[level]);
            }
            float moonX=330-camera*.055f;
            circle(c,moonX,160,29,"#DCEAD9");
            p.setColor(sky);c.drawCircle(moonX+10,150,28,p);
            // Distinct procedural scenery for each world, all behind gameplay.
            if(level==1){ // lagoon: distant sea, bubbles and reeds
                for(int i=0;i<11;i++){float xx=depthX(i*49,.2f,-2);float yy=h-175+(i*47%90)+wave(clock*1.4f+i)*7;paint("#508FC2");p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.6f);c.drawCircle(xx,yy,2+i%4,p);p.setStyle(Paint.Style.FILL);}
                for(int i=0;i<8;i++){float xx=depthX(i*63,.27f,.5f);paint("#56C8A5");p.setStrokeWidth(3);c.drawLine(xx,h-80,xx+wave(clock+i)*8,h-125-(i%3)*13,p);}
            }else if(level==2){ // cotton-candy islands
                for(int i=0;i<6;i++){float xx=depthX(i*92,.2f,1.2f);float yy=h-240+(i%3)*45;cloud(c,xx,yy,20+i%3*7,col(i%2==0?"#D98DBD":"#F3B6D2"));star(c,xx+16,yy-23,4,"#FFE9AA");}
            }else if(level==3){ // crystal cavern, stalactites and gems
                for(int i=0;i<12;i++){float xx=depthX(i*47,.22f,0);Path spike=new Path();spike.moveTo(xx-14,142);spike.lineTo(xx+14,142);spike.lineTo(xx,185+(i%4)*22);spike.close();paint(i%2==0?"#3B648B":"#517CA6");c.drawPath(spike,p);star(c,xx,h-110-(i%3)*22,3,"#9BEAFF");}
            }else if(level==4){ // alien planets and orbiting motes
                circle(c,80-camera*.04f,245,36,"#7852AD");circle(c,68-camera*.04f,233,11,"#A885D2");
                paint("#F0A5DE");p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawOval(27-camera*.04f,231,133-camera*.04f,258,p);p.setStyle(Paint.Style.FILL);
                for(int i=0;i<9;i++){float xx=depthX(i*59,.1f,.4f);star(c,xx,310+(i*37%170),2+i%2,"#D7B7FF");}
            }else{ // garden fireflies
                for(int i=0;i<9;i++){float xx=depthX(i*59,.2f,.8f);circle(c,xx,h-175-(i*29%90)+wave(clock*2+i)*6,2,"#FFE7A1");}
            }
            // Two independent cloud planes: sky cloud slow; closer cloud faster.
            for(int i=0;i<5;i++){
                float x=depthX(35+i*135,.12f,1.7f+i*.3f);
                float y=185+(i*97%170)+wave(clock*.35f+i)*4;
                cloud(c,x,y,17+(i%3)*7,mix(sky,col("#B2CEE3"),.16f));
            }
            hills(c,h-112,85,mix(valley,col("#9AC6CB"),.22f),.17f,.5f);
            for(int i=0;i<4;i++){
                float x=depthX(-10+i*160,.33f,-2.2f);
                float y=h-198+(i%2)*50+wave(clock*.25f+i)*3;
                cloud(c,x,y,24+(i%2)*11,mix(valley,col("#D3E0DD"),.17f));
            }
            hills(c,h-73,75,mix(valley,col("#67A5A4"),.25f),.39f,-.35f);
            hills(c,h-38,39,mix(valley,col("#304E5C"),.36f),.65f,-.75f);
            // The ground is a separate near plane; the cat is in front of it.
            p.setColor(mix(valley,col("#152B3B"),.48f));
            c.drawRect(0,h-38,w,h,p);
            p.setStrokeWidth(1.5f);p.setStrokeCap(Paint.Cap.ROUND);
            for(int i=0;i<33;i++){
                float x=depthX(i*17-15,.82f,-1.6f);
                float tip=wave(clock*1.9f+i*1.7f)*3;
                p.setColor(mix(valley,col("#ACD9AA"),i%3==0?.52f:.32f));
                c.drawLine(x,h-35,x+tip,h-39-(i%4)*3,p);
            }
        }
        void foreground(Canvas c){
            // Closest meadow drifts fastest. Kept below the cat's feet.
            p.setColor(mix(themeColor(bottom),col("#182C38"),.57f));
            c.drawRect(0,h-35,w,h,p);
            p.setStrokeWidth(2);p.setStrokeCap(Paint.Cap.ROUND);
            for(int i=0;i<29;i++){
                float x=depthX(i*19-20,1.25f,-3.4f);
                float flex=wave(clock*2+i*1.3f)*4;
                p.setColor(mix(themeColor(bottom),col("#A0D69F"),i%4==0?.55f:.28f));
                c.drawLine(x,h-17,x+flex-3,h-40-(i%5)*3,p);
                if(i%7==0){circle(c,x+flex-3,h-42-(i%5)*3,2.3f,"#FFD5A1");}
            }
        }
        void object(Canvas c,Drop d){
            c.save();c.translate(d.x,d.y);c.rotate(d.angle);
            if(d.kind==2)bomb(c,0,0);
            else if(d.kind==1)donut(c,0,0);
            else if(d.kind==0){circle(c,0,0,22,"#394452");star(c,0,0,16,"#FFE09A");}
            else if(d.kind==3){
                Path tail=new Path();tail.moveTo(-10,0);tail.lineTo(-26,-13);tail.lineTo(-26,13);tail.close();paint("#75E6D2");c.drawPath(tail,p);
                paint("#A2F2DF");c.drawOval(-17,-12,19,12,p);circle(c,10,-3,2.5f,"#163B50");
                paint("#45BAAE");p.setStrokeWidth(2);c.drawLine(-1,-6,-1,6,p);
            }else if(d.kind==4){
                Path wrap=new Path();wrap.moveTo(-12,0);wrap.lineTo(-25,-12);wrap.lineTo(-25,12);wrap.close();wrap.moveTo(12,0);wrap.lineTo(25,-12);wrap.lineTo(25,12);wrap.close();paint("#F5CB80");c.drawPath(wrap,p);
                box(c,-16,-12,32,24,9,"#F28ABA");box(c,-5,-12,8,24,3,"#FFE4F0");
            }else if(d.kind==5){
                Path gem=new Path();gem.moveTo(-19,-6);gem.lineTo(-10,-18);gem.lineTo(10,-18);gem.lineTo(19,-6);gem.lineTo(0,23);gem.close();paint("#91DDFF");c.drawPath(gem,p);
                Path facet=new Path();facet.moveTo(-9,-6);facet.lineTo(9,-6);facet.lineTo(0,23);facet.close();paint("#D2F5FF");c.drawPath(facet,p);star(c,9,-14,5,"#FFFFFF");
            }else{
                circle(c,0,0,16,"#C3A1FF");circle(c,-5,-5,5,"#E5CCFF");paint("#FFDDA7");p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);c.drawOval(-25,-7,25,8,p);p.setStyle(Paint.Style.FILL);
            }
            c.restore();
        }
        void cat(Canvas c,float x,float y){
            float run=Math.min(1,Math.abs(motion.v)/240);
            float stride=(float)Math.sin(motion.phase)*run;
            float bob=-Math.abs((float)Math.sin(motion.phase))*4*run+(float)Math.sin(clock*2)*.7f;
            float hop=joy>0?-(float)Math.sin((1-joy/.35f)*Math.PI)*7:0;
            paint("#29101D36");c.drawOval(x-29,y+32,x+29,y+41,p);
            c.save();c.translate(x,y+bob+hop);c.rotate(motion.v/540*7);
            Path tail=new Path();tail.moveTo(-facing*17,17);tail.cubicTo(-facing*42,20,-facing*48,-4,-facing*(40+5*(float)Math.sin(clock*4)),-15);
            paint("#E79968");p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(9);p.setStrokeCap(Paint.Cap.ROUND);c.drawPath(tail,p);p.setStyle(Paint.Style.FILL);
            box(c,-23+stride*7,25-Math.max(0,stride)*7,19,12,6,"#E9A271");
            box(c,4-stride*7,25-Math.max(0,-stride)*7,19,12,6,"#FFCB99");
            box(c,-21,-8,42,39,18,"#FFBC85");box(c,-12,10,24,16,7,"#FFE1B6");
            c.save();c.translate(facing*3,-run*1.5f);c.rotate(-motion.v/540*3);
            Path ears=new Path();ears.moveTo(-27,-12);ears.lineTo(-28,-44);ears.lineTo(-6,-29);ears.lineTo(6,-29);ears.lineTo(28,-44);ears.lineTo(27,-12);ears.close();paint("#FFBC85");c.drawPath(ears,p);
            box(c,-24,-36,9,11,4,"#ED9B92");box(c,15,-36,9,11,4,"#ED9B92");
            box(c,-29,-31,58,45,20,"#FFBC85");
            boolean blink=clock%4.8f<.13f;
            if(blink){box(c,-14+facing*2,-13,7,2,1,"#17243D");box(c,8+facing*2,-13,7,2,1,"#17243D");}
            else{circle(c,-10+facing*2,-12,3.2f,"#17243D");circle(c,12+facing*2,-12,3.2f,"#17243D");}
            circle(c,facing*3,-3,3,"#C26D65");circle(c,-19,-3,4,"#F29A86");circle(c,21,-3,4,"#F29A86");
            paint("#AD705F");p.setStrokeWidth(1.4f);c.drawLine(-20,1,-34,-1,p);c.drawLine(22,1,34,-1,p);
            c.restore();c.restore();
        }
        void reset(){saveBest();motion.reset();accumulator=0;clock=0;camera=0;facing=1;joy=0;level=0;theme=0;levelBanner=0;score=0;lives=3;elapsed=0;spawn=.25f;invincible=0;flash=0;deathTimer=0;sparks.clear();drops.clear();cat=target=200;state=1;last=0;}
        void update(float dt){
            elapsed+=dt;invincible=Math.max(0,invincible-dt);motion.step(target,dt);cat=motion.x;
            float direction=Math.abs(motion.v)>12?(motion.v>0?1:-1):facing;facing+=(direction-facing)*Math.min(1,dt*12);
            spawn-=dt;
            if(spawn<=0){
                spawn=Math.max(.32f,.74f-level*.075f);
                float roll=random.nextFloat();
                if(drops.size()<GameRules.MAX_DROPS)
                    drops.add(new Drop(30+random.nextFloat()*340,95+level*24+random.nextFloat()*28,GameRules.chooseKind(level,roll,random.nextInt(10000))));
            }
            for(int i=drops.size()-1;i>=0;i--){
                Drop d=drops.get(i);d.age+=dt;
                d.speed=Math.min(330+level*15,d.speed+(d.kind==2?33:20)*dt);d.y+=d.speed*dt;
                d.angle=d.kind==2?(float)Math.sin(d.age*3)*12:d.kind==3?(float)Math.sin(d.age*4)*18:d.age*(d.kind==5?35:55);
                float dx=d.x-cat,dy=d.y-(h-110);
                if(dx*dx+dy*dy<35*35){
                    // During the brief protection window bombs pass without exploding.
                    if(d.kind==2&&invincible>0)continue;
                    drops.remove(i);
                    if(d.kind==2){
                        lives--;invincible=1.2f;flash=.18f;burst(d.x,d.y,true);buzz(100);
                        if(lives==0){
                            state=4;deathTimer=.7f;
                            if(score>best)best=score;saveBest();
                            break;
                        }
                    }else{
                        score+=GameRules.points(d.kind);if(score>best)best=score;joy=.35f;burst(d.x,d.y,false);buzz(d.kind==0?28:45);
                        int next=GameRules.levelFor(score);if(next>level){level=next;levelBanner=2.8f;spawn=Math.max(spawn,.7f);}
                    }
                }else if(d.y>h+30)drops.remove(i);
            }
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);if(getWidth()==0)return;scale=getWidth()/w;h=getHeight()/scale;
            long now=System.nanoTime();float dt=last==0?0:Math.min(.1f,(now-last)/1e9f);last=now;
            if(active&&(state==1||state==4)){
                accumulator+=dt;
                while(accumulator>=1f/120){effects(1f/120);if(state==1)update(1f/120);accumulator-=1f/120;}
            }else if(active&&state==0)clock+=dt;
            c.save();c.scale(scale,scale);
            if(flash>0)c.translate(wave(clock*76)*flash*11,wave(clock*91)*flash*6);
            background(c);
            box(c,18,28,364,67,20,"#1C304B");label(c,"BODOVI",72,52,10,"#A3BECF",true);label(c,""+score,72,78,25,"#FFFFFF",true);label(c,"REKORD  "+best,207,65,12,"#A3BECF",true);
            for(int i=0;i<3;i++)circle(c,316+i*20,62,6,i<lives?"#FFBC85":"#40536A");
            label(c,"RAZINA "+(level+1)+" · "+names[level],200,116,12,"#DEECF2",true);
            box(c,70,126,260,4,2,"#40556D");
            float progress=level==4?1:(float)(score-GameRules.THRESHOLDS[level])/(GameRules.THRESHOLDS[level+1]-GameRules.THRESHOLDS[level]);
            box(c,70,126,260*progress,4,2,"#FFCE96");
            for(Drop d:drops)object(c,d);
            if(invincible<=0||((int)(invincible*12))%2==0)cat(c,cat,h-110);
            foreground(c);
            for(Spark s:sparks){p.setColor(s.color);p.setAlpha((int)(255*s.life/s.total));c.drawCircle(s.x,s.y,2+5*s.life/s.total,p);}p.setAlpha(255);
            label(c,"Povuci prst lijevo ili desno",190,h-23,12,"#AAC6D3",false);
            if(state==1){box(c,354,h-70,34,34,10,"#C8304556");label(c,"Ⅱ",371,h-47,17,"#FFFFFF",true);}
            if(levelBanner>0&&state==1){
                float t=Math.min(1,levelBanner);paint("#E61D3450");p.setAlpha((int)(230*t));c.drawRoundRect(38,h*.3f-30,362,h*.3f+49,18,18,p);p.setAlpha(255);
                label(c,"NOVA RAZINA "+(level+1),200,h*.3f,15,"#FFDEAA",true);
                label(c,names[level],200,h*.3f+23,20,"#FFFFFF",true);
                label(c,meteorNames[level],200,h*.3f+42,11,"#FFD4AA",false);
            }
            if(flash>0){paint("#33FF7766");c.drawRect(0,0,w,h,p);}
            if(state!=1&&state!=4){paint("#B8101D36");c.drawRect(0,100,w,h-50,p);float cy=h*.45f;box(c,28,cy-110,344,265,25,"#1D3450");
                if(state==0){label(c,"ZVJEZDANA MAČKA",200,cy-62,24,"#FFE1B6",true);label(c,"5 svjetova · jedna gladna mačka",200,cy-30,16,"#BED3DE",false);label(c,"Zvijezda +10 • Krafnica +25",200,cy+8,14,"#FFFFFF",false);label(c,"Izbjegni bombe — imaš 3 života!",200,cy+33,13,"#BED3DE",false);}
                else if(state==2){label(c,"GAME OVER",200,cy-62,25,"#FFE1B6",true);label(c,score+" bodova",200,cy-19,32,"#FFFFFF",true);label(c,"Najbolji rezultat: "+best,200,cy+25,15,"#BED3DE",false);}
                else{label(c,"MALA PAUZA",200,cy-42,25,"#FFE1B6",true);label(c,"Zvijezde te čekaju.",200,cy+3,16,"#BED3DE",false);}
                box(c,70,cy+70,260,53,18,"#FFCB8E");label(c,state==0?"KRENI U AVANTURU":state==2?"IGRAJ PONOVNO":"NASTAVI",200,cy+103,15,"#17243D",true);
            }
            c.restore();if(active&&(state==0||state==1||state==4))postInvalidateDelayed(15);
        }
        @Override public boolean onTouchEvent(MotionEvent e){float x=e.getX()/scale,y=e.getY()/scale;if(state==4)return true;if(state!=1){if(e.getActionMasked()==MotionEvent.ACTION_DOWN&&x>=70&&x<=330&&y>=h*.45f+70&&y<=h*.45f+123){if(state==3){state=resumeState;last=0;accumulator=0;}else reset();invalidate();}return true;}if(e.getActionMasked()==MotionEvent.ACTION_DOWN&&x>=347&&y>=h-80&&y<=h-25){resumeState=1;state=3;last=0;accumulator=0;invalidate();return true;}if(e.getActionMasked()==MotionEvent.ACTION_DOWN||e.getActionMasked()==MotionEvent.ACTION_MOVE){target=Math.max(32,Math.min(368,x));}return true;}
    }
}
