# Zvjezdana mačka — razvojna verzija 0.4

Nastavak Astrinog Android Canvas prototipa 0.3, s istim package nameom
`hr.frane.zvjezdana` i istim **testnim** potpisnim ključem. Nema vanjskih
biblioteka, oglasa, mrežnih dozvola ni slika velikih dimenzija.

## Nova scena (2.5D)

- Tri brdovita sloja s različitim brzinama paralakse i pomicanjem kamere prema mački.
- Daleke zvijezde koje trepere, mjesec, povremena zvijezda padalica.
- Dva sloja oblaka različite brzine, trava i cvjetići u najbližem planu.
- Boje se postupno mijenjaju kroz originalnih pet svjetova.
- Kratki, blagi pomak scene pri eksploziji; ostaju originalne animacije mačke.
- Tipka za pauzu desno pri dnu; povratak tipkom NASTAVI.
- Ograničenje čestica na 110 i objekata na 48, postInvalidateDelayed(15)
  smanjuje nepotrebne pozive crtanja na zaslonima visoke frekvencije.
- Rekord se prikazuje odmah i zapisuje pri pauzi, resetu i završetku partije.

## Izvorni gameplay

Prstom pomiči mačku, skupljaj zvijezde (+10), krafnice (+25), ribice
(+30), bombone (+35), kristale (+45) i planete (+60). Izbjegavaj bombe.
3 života, kratka zaštita nakon pogotka i eksplozija nakon trećeg života.
Pet svjetova otključava se na 0 / 150 / 400 / 800 / 1400 bodova.

## Kompiliranje APK-a

Zahtjevi: Android SDK platform `android-35`, build-tools `35.0.0`,
JDK 17 (ili opcionalno ECJ 3.33.0 u ECJ_JAR) i Python 3.

```bash
export ANDROID_SDK_ROOT="$HOME/Android/Sdk"
bash build.sh
```

Rezultat: `build/Zvjezdana-Macka-0.4.apk`.
Uključeni `test-signing.p12` ima alias `test` i lozinku `android`;
**nije siguran za Play Store**. Služi samo instalaciji razvojnih verzija.
Potpisi v1/v2/v3 provjeravaju se u `build.sh`.

## Provjera host-side logike

```bash
mkdir -p build/test-classes
javac -d build/test-classes src/hr/frane/zvjezdana/GameRules.java tests/RulesTest.java
java -cp build/test-classes RulesTest
```

Host-side test provjerava pravila, kretanje u fiksnom vremenskom koraku,
novi raspon paralakse, cilj kamere i ograničenja elemenata.
Prikaz i vibracija moraju se dodatno provjeriti na stvarnom Android uređaju.

## GitHub Actions (bez lokalnog Android SDK-a)

U zaseban GitHub repozitorij stavi **sadržaj** mape `cat-game/` u korijen
repozitorija, uključujući `.github/workflows/build-apk.yml`. GitHub Actions
će nakon pusha kompilirati i testirati APK. Na kartici pojedinog runa pod
**Artifacts** preuzmi `Zvjezdana-Macka-0.4`. Postojeći testni potpisni ključ
podržava razvojnu nadogradnju instalirane verzije 0.3 ako je i ona potpisana
tim istim ključem. Ako Android javi da potpisi nisu jednaki, ukloni staru
instalaciju tek nakon spremanja važnih podataka (rekord se pri uklanjanju briše).
